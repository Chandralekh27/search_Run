import tkinter as tk
from tkinter import ttk


window = tk.Tk()

window.title("search")
window.minsize(200,50)

def clickMe():
    label.configure(text= 'Hello ' + name.get())
def showprint():
    print(  name)

label = ttk.Label(window, text = "Enter Your Name")
label.grid(column = 0, row = 0)




name = tk.StringVar()
nameEntered = ttk.Entry(window, width = 20, textvariable = name)
nameEntered.grid(column = 2, row = 2)


button = ttk.Button(window, text = "Click Me",command= showprint )
button.grid(column= 0, row = 2)

window.mainloop()